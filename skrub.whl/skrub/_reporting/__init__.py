"""Summarize the contents of a dataframe and generate an HTML report."""

from ._table_report import TableReport

__all__ = ["TableReport"]
